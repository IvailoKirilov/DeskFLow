# DeskFlow design

## A workday coming into focus

DeskFlow opens with an office interior revealed through a widening panel. The next five workdays sit across the lower edge of that scene. The clay accent carries from the selected date to the desk, then a beam of light reveals the large desk number in the choice summary.

A second option would use a quiet, image-free editorial timetable that emphasizes date comparison. A third would derive the grid from office signage and carry the zone into a printed pass. The aperture direction adds atmosphere to the entry and a visible cue to selection while keeping the practical choices immediately available.

Unseen Studio was a reference for layered media, editorial rhythm, and transitions that connect states. DeskFlow uses its own licensed office photography, typography, outlined workweek, and reservation interaction. The interface has its own brand, surface treatments and light and dark palettes.

## Implementation

- Theme tokens pair mineral green-black with linen, clay, and muted moss. The opening scene stays dark for legibility in either theme.
- Oswald is used for the headline and precise numerals. Fira Sans serves controls, metadata and status text.
- The entrance reveals only the decorative photo. Zone changes settle in 360 ms. Selecting a desk reveals its number in 560 ms and sweeps the panel in 620 ms, with captions and confirmation immediately available.
- On phones today's status and all five dates appear above the desk grid. A selected summary sticks at the lower edge.
- Fieldsets, radio groups, native links and server-side form handlers supply the basic flow. Motion and zone filtering are enhancements.
- Razor Pages, SQLite, localized date logic, eligibility rules, and reservation handlers are the existing DeskFlow implementation.
