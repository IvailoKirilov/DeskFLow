// Follow the device until the visitor chooses a DeskFlow-specific setting.
const deskMotion = (() => {
  const device = matchMedia('(prefers-reduced-motion: no-preference)');
  const key = 'deskflow-motion';
  const events = new EventTarget();
  const rules = [];
  let preference;
  function read() {
    try { preference = localStorage.getItem(key); } catch { preference = null; }
  }
  function enabled() {
    return preference === 'full' || (preference !== 'reduced' && device.matches);
  }
  function sync() {
    for (const { rule, original, full } of rules) {
      rule.media.mediaText = preference ? (enabled() === full ? 'all' : 'not all') : original;
    }
    const button = document.querySelector('[data-motion-toggle]');
    button?.setAttribute('aria-pressed', String(enabled()));
    button?.setAttribute('title', enabled() ? 'Изключи анимациите' : 'Включи анимациите');
    events.dispatchEvent(new Event('change'));
  }
  read();
  device.addEventListener('change', sync);
  window.addEventListener('storage', e => {
    if (!e.key || e.key === key) { read(); sync(); }
  });
  document.addEventListener('DOMContentLoaded', () => {
    for (const sheet of document.styleSheets) {
      for (const rule of sheet.cssRules) {
        const original = rule.media?.mediaText;
        if (/^\(prefers-reduced-motion: (reduce|no-preference)\)$/.test(original)) {
          rules.push({ rule, original, full: original.includes('no-preference') });
        }
      }
    }
    const button = document.querySelector('[data-motion-toggle]');
    if (button) {
      button.hidden = false;
      button.addEventListener('click', () => {
        preference = enabled() ? 'reduced' : 'full';
        try { localStorage.setItem(key, preference); } catch {}
        sync();
      });
    }
    sync();
  });
  return { enabled, events };
})();

// Name the transition on both sides of a server redirect or history traversal.
function preparePageTransition(transition, activation) {
  if (!transition) return;
  if (!deskMotion.enabled()) {
    transition.skipTransition();
    return;
  }
  if (!activation?.from || !activation.entry) return;
  const previous = new URL(activation.from.url);
  const next = new URL(activation.entry.url);
  if (previous.pathname !== next.pathname) transition.types?.add('doorway');
}
window.addEventListener('pageswap', event => preparePageTransition(event.viewTransition, event.activation));
window.addEventListener('pagereveal', event => preparePageTransition(event.viewTransition, window.navigation?.activation));
