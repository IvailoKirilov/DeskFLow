const refresh = document.querySelector('[data-refresh-ms]')?.dataset.refreshMs;
if (refresh && Number(refresh) > 0) {
  window.setTimeout(() => window.location.reload(), Number(refresh));
}

const loadingStatus = document.createElement('span');
loadingStatus.className = 'sr-only';
loadingStatus.setAttribute('role', 'status');
document.body.append(loadingStatus);

let loadingTimer;

function showLoadingIfSlow() {
  if (loadingTimer !== undefined) return;
  // Give fast navigations time to finish without flashing a loading bar.
  loadingTimer = window.setTimeout(() => {
    document.body.classList.add('is-loading');
    loadingStatus.textContent = 'Зареждане…';
  }, 180);
}

window.addEventListener('submit', event => {
  if (!event.defaultPrevented && event.target.method === 'post') {
    showLoadingIfSlow();
  }
});

window.addEventListener('click', event => {
  if (event.defaultPrevented || event.button !== 0
      || event.ctrlKey || event.metaKey || event.shiftKey || event.altKey) return;
  if (event.target.closest('[data-workweek] a')) showLoadingIfSlow();
});

window.addEventListener('pagehide', () => {
  window.clearTimeout(loadingTimer);
  loadingTimer = undefined;
  document.body.classList.remove('is-loading');
  loadingStatus.textContent = '';
});

const reservation = document.querySelector('#desk-reservation');
if (reservation) {
  const navigation = reservation.querySelector('[data-zone-nav]');
  const zoneButtons = [...navigation.querySelectorAll('button')];
  const panels = [...reservation.querySelectorAll('fieldset')];
  const ticket = document.querySelector('[data-booking-pass]');
  const submit = ticket.querySelector('[type="submit"]');
  const choice = ticket.querySelector('[data-choice]');
  const beam = ticket.querySelector('.df-pass-beam');
  const number = choice.querySelector('[data-choice-number]');
  const name = choice.querySelector('[data-choice-name]');
  const detail = choice.querySelector('[data-choice-detail]');

  const ease = getComputedStyle(ticket).getPropertyValue('--df-ease').trim();
  let passAnimation;
  let seatAnimation;
  let zoneAnimation;
  let beamAnimation;

  function updateChoice() {
    const desk = reservation.querySelector('input[type="radio"]:checked');
    number.textContent = desk?.dataset.number ?? '··';
    name.textContent = desk?.dataset.name ?? 'Избери бюро';
    detail.textContent = desk ? `${desk.dataset.zone} · ${desk.value}` : '';
    detail.hidden = !desk;
    submit.disabled = !desk;
    ticket.classList.toggle('has-choice', Boolean(desk));
  }

  function showZone(id) {
    for (const panel of panels) {
      panel.hidden = panel.id !== id;
      panel.disabled = panel.hidden;
      const previous = panel.querySelector('input:checked');
      if (panel.hidden && previous) previous.checked = false;
    }
    for (const button of zoneButtons) {
      button.setAttribute('aria-pressed', String(button.getAttribute('aria-controls') === id));
    }
    updateChoice();
  }

  navigation.hidden = zoneButtons.length < 2;
  reservation.classList.toggle('has-zone-nav', !navigation.hidden);
  navigation.addEventListener('click', event => {
    const button = event.target.closest('button');
    if (!button || button.getAttribute('aria-pressed') === 'true') return;
    const id = button.getAttribute('aria-controls');
    passAnimation?.cancel();
    beamAnimation?.cancel();
    showZone(id);
    zoneAnimation?.cancel();
    if (deskMotion.enabled()) {
      zoneAnimation = document.getElementById(id).animate(
        [{ opacity: .65, transform: 'translateY(8px)' }, { opacity: 1, transform: 'translateY(0)' }],
        { duration: 360, easing: ease }
      );
    }
  });
  reservation.addEventListener('change', event => {
    updateChoice();
    passAnimation?.cancel();
    beamAnimation?.cancel();
    seatAnimation?.cancel();
    if (deskMotion.enabled()) {
      passAnimation = number.animate(
        [{ opacity: .35, clipPath: 'inset(0 88% 0 0)', transform: 'translateX(-8px)' },
          { opacity: 1, clipPath: 'inset(0 0 0 0)', transform: 'translateX(0)' }],
        { duration: 560, easing: ease }
      );
      beamAnimation = beam.animate(
        [{ opacity: 0, transform: 'translateX(-100%)' },
          { opacity: .42, offset: .44 },
          { opacity: 0, transform: 'translateX(180%)' }],
        { duration: 620, easing: ease }
      );
      seatAnimation = event.target.nextElementSibling.animate(
        [{ transform: 'scale(.93)' }, { transform: 'scale(1.05)', offset: .56 }, { transform: 'scale(1)' }],
        { duration: 370, easing: ease }
      );
    }
  });
  deskMotion.events.addEventListener('change', () => {
    if (deskMotion.enabled()) return;
    passAnimation?.cancel();
    beamAnimation?.cancel();
    seatAnimation?.cancel();
    zoneAnimation?.cancel();
  });
  const current = reservation.querySelector('input:checked')?.closest('fieldset');
  showZone(current?.id ?? panels[0].id);
  window.addEventListener('pageshow', updateChoice);
}

// Each tab gets one arrival and one dashboard introduction. Native navigation
// handles subsequent visits, validation and submissions without waiting.
(() => {
  const arrival = document.querySelector('.arrival-ready');
  const dashboard = document.querySelector('.df-page');
  if (!arrival && !dashboard) return;
  const key = arrival ? 'deskflow-arrival-seen' : 'deskflow-workspace-seen';
  try {
    if (!sessionStorage.getItem(key)) {
      (arrival || dashboard).classList.add(arrival ? 'arrival-enter' : 'first-dashboard');
      sessionStorage.setItem(key, '1');
    }
  } catch { /* Keep the static composition when tab storage is unavailable. */ }

  if (dashboard && dashboard.classList.contains('first-dashboard') && 'IntersectionObserver' in window) {
    const reveal = new IntersectionObserver(entries => {
      for (const entry of entries) {
        if (entry.isIntersecting) {
          entry.target.classList.add('in-view');
          reveal.unobserve(entry.target);
        }
      }
    });
    document.querySelectorAll('.df-floor-heading,.df-pass').forEach(node => reveal.observe(node));
  }

  const stage = arrival || document.querySelector('.df-hero');
  const photo = stage.querySelector('.room-shot,.df-hero-image');
  const enabled = matchMedia('(hover: hover) and (pointer: fine) and (prefers-reduced-motion: no-preference)');
  let x = 0, y = 0, aimX = 0, aimY = 0, frame = 0, lastTime = 0;
  function paint(time) {
    frame = 0;
    const blend = 1 - Math.exp(-Math.min(64, time - lastTime || 16) / 95);
    lastTime = time;
    const scroll = Math.min(6, Math.max(0, -stage.getBoundingClientRect().top / 25));
    const targetY = aimY + scroll;
    x += (aimX - x) * blend;
    y += (targetY - y) * blend;
    photo.style.setProperty('--depth-x', x.toFixed(2) + 'px');
    photo.style.setProperty('--depth-y', y.toFixed(2) + 'px');
    photo.style.setProperty('--light-x', (-2 * x).toFixed(2) + 'px');
    if (Math.abs(x - aimX) + Math.abs(y - targetY) > .04) schedule();
  }
  function schedule() {
    if (enabled.matches && !frame) frame = requestAnimationFrame(paint);
  }
  stage.addEventListener('pointermove', event => {
    if (!enabled.matches || event.pointerType === 'touch') return;
    const rect = stage.getBoundingClientRect();
    aimX = ((event.clientX - rect.left) / rect.width - .5) * 14;
    aimY = ((event.clientY - rect.top) / rect.height - .5) * 6;
    schedule();
  });
  stage.addEventListener('pointerleave', () => { aimX = aimY = 0; schedule(); });
  window.addEventListener('scroll', schedule, { passive: true });
  enabled.addEventListener('change', () => {
    cancelAnimationFrame(frame);
    frame = x = y = aimX = aimY = 0;
    for (const prop of ['--depth-x','--depth-y','--light-x']) photo.style.removeProperty(prop);
  });
})();

// Start the gesture on the outgoing document and finish it on the chosen date.
(() => {
  const week = document.querySelector('[data-workweek]');
  if (!week) return;
  const hero = week.closest('.df-hero');
  const current = week.querySelector('[aria-current="date"]');
  const key = 'deskflow-date-gesture';
  function sweep(day, origin) {
    week.querySelector('.day-filling')?.classList.remove('day-filling');
    hero.classList.remove('day-changing');
    hero.style.setProperty('--sweep-color', getComputedStyle(day).getPropertyValue('--day-tint'));
    day.style.setProperty('--origin', origin + '%');
    void hero.offsetWidth;
    hero.classList.add('day-changing');
    day.classList.add('day-filling');
  }
  week.addEventListener('click', event => {
    const day = event.target.closest('a');
    if (!day || event.defaultPrevented || event.button || event.metaKey || event.ctrlKey || event.shiftKey || event.altKey) return;
    const box = day.getBoundingClientRect();
    const origin = event.detail ? Math.max(0, Math.min(100, 100 * (event.clientX - box.left) / box.width)) : 50;
    sweep(day, origin);
    if (day === current) {
      event.preventDefault();
      return;
    }
    try { sessionStorage.setItem(key, JSON.stringify({ url: day.href, origin, time: Date.now() })); } catch {}
  });
  try {
    const gesture = JSON.parse(sessionStorage.getItem(key));
    sessionStorage.removeItem(key);
    if (current && gesture?.url === location.href && Date.now() - gesture.time < 30000) {
      const finish = () => sweep(current, gesture.origin);
      if (document.activeViewTransition) document.activeViewTransition.finished.then(finish);
      else finish();
    }
  } catch {}
})();

