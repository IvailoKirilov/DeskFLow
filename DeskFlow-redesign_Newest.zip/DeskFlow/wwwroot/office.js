const refresh = document.querySelector('[data-refresh-ms]')?.dataset.refreshMs;
if (refresh && Number(refresh) > 0) {
  window.setTimeout(() => window.location.reload(), Number(refresh));
}

const loadingStatus = document.createElement('span');
loadingStatus.className = 'sr-only';
loadingStatus.setAttribute('role', 'status');
document.body.append(loadingStatus);

let loadingTimer;

function showLoadingIfSlow() {
  if (loadingTimer !== undefined) return;
  // Give fast navigations time to finish without flashing a loading bar.
  loadingTimer = window.setTimeout(() => {
    document.body.classList.add('is-loading');
    loadingStatus.textContent = 'Зареждане…';
  }, 180);
}

window.addEventListener('submit', event => {
  if (!event.defaultPrevented && event.target.method === 'post') {
    showLoadingIfSlow();
  }
});

window.addEventListener('click', event => {
  if (event.defaultPrevented || event.button !== 0
      || event.ctrlKey || event.metaKey || event.shiftKey || event.altKey) return;
  if (event.target.closest('.dates a')) showLoadingIfSlow();
});

window.addEventListener('pagehide', () => {
  window.clearTimeout(loadingTimer);
  loadingTimer = undefined;
  document.body.classList.remove('is-loading');
  loadingStatus.textContent = '';
});

const reservation = document.querySelector('.reservation');
if (reservation) {
  const navigation = reservation.querySelector('.zone-nav');
  const zoneButtons = [...navigation.querySelectorAll('button')];
  const panels = [...reservation.querySelectorAll('fieldset')];
  const submit = reservation.querySelector('[type="submit"]');
  const choice = reservation.querySelector('[data-choice]');

  function updateChoice() {
    const desk = reservation.querySelector('input[type="radio"]:checked');
    choice.textContent = desk ? desk.dataset.name + ' · ' + desk.dataset.zone : 'Избери свободно бюро';
    submit.disabled = !desk;
  }

  function showZone(id) {
    for (const panel of panels) {
      panel.hidden = panel.id !== id;
      panel.disabled = panel.hidden;
      const previous = panel.querySelector('input:checked');
      if (panel.hidden && previous) previous.checked = false;
    }
    for (const button of zoneButtons) {
      button.setAttribute('aria-pressed', String(button.getAttribute('aria-controls') === id));
    }
    updateChoice();
  }

  navigation.hidden = zoneButtons.length < 2;
  reservation.classList.toggle('has-zone-nav', !navigation.hidden);
  navigation.addEventListener('click', event => {
    const button = event.target.closest('button');
    if (button) showZone(button.getAttribute('aria-controls'));
  });
  reservation.addEventListener('change', updateChoice);
  const current = reservation.querySelector('input:checked')?.closest('fieldset');
  showZone(current?.id ?? panels[0].id);
  window.addEventListener('pageshow', updateChoice);
}
