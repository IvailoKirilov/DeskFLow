(() => {
  const preferenceKey = 'deskflow-theme';
  const systemTheme = window.matchMedia('(prefers-color-scheme: dark)');
  const reducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)');
  const root = document.documentElement;
  let preference;
  let activeTransition;
  let inkAnimation;

  function readPreference() {
    try {
      const saved = localStorage.getItem(preferenceKey);
      return saved === 'light' || saved === 'dark' ? saved : null;
    } catch {
      return null;
    }
  }

  function currentPreference() {
    return preference ?? (systemTheme.matches ? 'dark' : 'light');
  }

  function applyTheme() {
    const theme = currentPreference();
    root.dataset.theme = theme;
    document.querySelector('[data-theme-toggle]')?.setAttribute('aria-pressed', String(theme === 'dark'));
  }

  function inkOutline(x, y, radius, phase, ripple) {
    const pointCount = 10;
    const points = Array.from({ length: pointCount }, (_, index) => {
      const angle = index * 2 * Math.PI / pointCount;
      const swell = .65 * Math.sin(3 * angle + phase) + .35 * Math.cos(5 * angle - phase);
      const reach = radius * (1 + ripple * swell);
      return [x + reach * Math.cos(angle), y + reach * Math.sin(angle)];
    });
    const coordinates = (x, y) => x.toFixed(1) + ' ' + y.toFixed(1);
    let outline = 'M ' + coordinates(...points[0]);

    // Round each lobe by deriving its handles from the neighboring points.
    for (let i = 0; i < pointCount; i++) {
      const [px, py] = points[(i + pointCount - 1) % pointCount];
      const [ax, ay] = points[i];
      const [bx, by] = points[(i + 1) % pointCount];
      const [nx, ny] = points[(i + 2) % pointCount];
      outline += ' C ' + coordinates(ax + (bx - px) / 6, ay + (by - py) / 6)
        + ', ' + coordinates(bx - (nx - ax) / 6, by - (ny - ay) / 6)
        + ', ' + coordinates(bx, by);
    }
    return 'path("' + outline + ' Z")';
  }

  async function animateTheme(toggle, goingDark) {
    if (inkAnimation && inkAnimation.playState !== 'finished' && !reducedMotion.matches) {
      inkAnimation.reverse();
      toggle.setAttribute('aria-pressed', String(goingDark));
      return;
    }

    if (activeTransition || reducedMotion.matches || !document.startViewTransition) {
      activeTransition?.skipTransition();
      applyTheme();
      return;
    }

    const bounds = toggle.getBoundingClientRect();
    const x = bounds.left + bounds.width / 2;
    const y = bounds.top + bounds.height / 2;
    const radius = Math.hypot(Math.max(x, innerWidth - x), Math.max(y, innerHeight - y));
    // Sample one continuous wave so its lobes pass smoothly through every keyframe.
    const keyframes = Array.from({ length: 21 }, (_, index) => {
      const t = index / 20;
      const reach = 2 + radius * 1.06 * t;
      const ripple = .28 * Math.sin(Math.PI * t);
      return { offset: t, clipPath: inkOutline(x, y, reach, .5 + t * 3.3, ripple) };
    });

    root.setAttribute('data-theme-transition', goingDark ? 'spread' : 'recede');
    const transition = document.startViewTransition(applyTheme);
    activeTransition = transition;
    try {
      await transition.ready;
      inkAnimation = root.animate(keyframes, {
        duration: 800,
        easing: 'cubic-bezier(.36, .04, .25, 1)',
        direction: goingDark ? 'normal' : 'reverse',
        fill: 'both',
        pseudoElement: goingDark ? '::view-transition-new(root)' : '::view-transition-old(root)',
      });
      await inkAnimation.finished;
      applyTheme();
      await transition.finished;
    } catch {
      // A resize or a hidden tab can end the snapshot early.
      transition.skipTransition();
      await transition.finished.catch(() => {});
      applyTheme();
    } finally {
      inkAnimation = null;
      activeTransition = null;
      root.removeAttribute('data-theme-transition');
    }
  }

  preference = readPreference();
  applyTheme();
  systemTheme.addEventListener('change', applyTheme);
  reducedMotion.addEventListener('change', event => {
    if (event.matches) activeTransition?.skipTransition();
  });
  window.addEventListener('storage', event => {
    if (event.key === preferenceKey || event.key === null) {
      preference = readPreference();
      activeTransition?.skipTransition();
      applyTheme();
    }
  });
  window.addEventListener('pageshow', event => {
    if (event.persisted) applyTheme();
  });

  document.addEventListener('DOMContentLoaded', () => {
    const toggle = document.querySelector('[data-theme-toggle]');
    if (!toggle) return;

    applyTheme();
    toggle.hidden = false;
    toggle.addEventListener('click', () => {
      const goingDark = currentPreference() === 'light';
      preference = goingDark ? 'dark' : 'light';
      try {
        localStorage.setItem(preferenceKey, preference);
      } catch {
        // The active page can still switch themes when storage is unavailable.
      }
      animateTheme(toggle, goingDark);
    });
  });
})();
